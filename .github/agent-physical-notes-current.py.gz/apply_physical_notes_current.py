from __future__ import annotations

from pathlib import Path


def replace_once(path: str, old: str, new: str) -> None:
    file_path = Path(path)
    text = file_path.read_text()
    count = text.count(old)
    if count != 1:
        raise RuntimeError(
            f"Expected exactly one anchor in {path}, found {count}: {old[:120]!r}",
        )
    file_path.write_text(text.replace(old, new, 1))


def append_after(path: str, anchor: str, addition: str) -> None:
    replace_once(path, anchor, anchor + addition)


# packages/assistant-engine/src/assistant-codex/dynamic-tools.ts
path = "packages/assistant-engine/src/assistant-codex/dynamic-tools.ts"
append_after(
    path,
    "import {\n  ASSISTANT_GENERATED_DELIVERY_DIRECTORY,\n} from '../assistant/generated-delivery-files.js'\n",
    "import {\n  readAssistantHostedImageCompletion,\n} from '../assistant/hosted-image-completion.js'\n",
)
append_after(
    path,
    "import {\n  createPhoneCallRequestKey,\n  MURPH_CREATE_PHONE_CALL_TOOL,\n  normalizePhoneCallBriefForConversationScope,\n  readPhoneCallDynamicToolRequest,\n  type PhoneCallDynamicToolRequest,\n} from './dynamic-tools/phone-calls.js'\n",
    "import {\n  createPhysicalNoteRequestKey,\n  MURPH_SEND_PHYSICAL_NOTE_TOOL,\n  readPhysicalNoteDynamicToolRequest,\n  type PhysicalNoteDynamicToolRequest,\n} from './dynamic-tools/physical-notes.js'\n"
    "export { MURPH_SEND_PHYSICAL_NOTE_TOOL } from './dynamic-tools/physical-notes.js'\n",
)
replace_once(
    path,
    "  MURPH_CREATE_CLINICAL_RECORDS_CONNECT_LINK_TOOL,\n  MURPH_CREATE_PHONE_CALL_TOOL,\n  MURPH_LABS_TOOL,\n",
    "  MURPH_CREATE_CLINICAL_RECORDS_CONNECT_LINK_TOOL,\n  MURPH_CREATE_PHONE_CALL_TOOL,\n  MURPH_SEND_PHYSICAL_NOTE_TOOL,\n  MURPH_LABS_TOOL,\n",
)
replace_once(
    path,
    "  productFeedbackAvailable?: boolean | null\n  progressUpdateMode?: 'direct' | 'group'\n  phoneCallsAvailable?: boolean | null\n",
    "  productFeedbackAvailable?: boolean | null\n  progressUpdateMode?: 'direct' | 'group'\n  physicalNotesAvailable?: boolean | null\n  phoneCallsAvailable?: boolean | null\n",
)
replace_once(
    path,
    "    [MURPH_SEND_VAULT_FILE_TOOL, defaultOff((a) => a.vaultFileSendAvailable)],\n"
    "    [MURPH_CREATE_PHONE_CALL_TOOL, defaultOff((a) => a.phoneCallsAvailable)],\n",
    "    [MURPH_SEND_VAULT_FILE_TOOL, defaultOff((a) => a.vaultFileSendAvailable)],\n"
    "    [MURPH_CREATE_PHONE_CALL_TOOL, defaultOff((a) => a.phoneCallsAvailable)],\n"
    "    [MURPH_SEND_PHYSICAL_NOTE_TOOL, defaultOff((a) => a.physicalNotesAvailable)],\n",
)
replace_once(
    path,
    "  | PhoneCallDynamicToolRequest\n  | ClinicalRecordsConnectLinkDynamicToolRequest\n",
    "  | PhoneCallDynamicToolRequest\n  | PhysicalNoteDynamicToolRequest\n  | ClinicalRecordsConnectLinkDynamicToolRequest\n",
)
replace_once(
    path,
    "  if (phoneCallRequest) {\n    return phoneCallRequest\n  }\n\n"
    "  const clinicalRecordsConnectLinkRequest =\n",
    "  if (phoneCallRequest) {\n    return phoneCallRequest\n  }\n\n"
    "  const physicalNoteRequest = readPhysicalNoteDynamicToolRequest({\n"
    "    arguments: request.arguments,\n"
    "    tool: request.tool,\n"
    "  })\n"
    "  if (physicalNoteRequest) {\n"
    "    return physicalNoteRequest\n"
    "  }\n\n"
    "  const clinicalRecordsConnectLinkRequest =\n",
)
replace_once(
    path,
    "    case 'invalid-phone-call-arguments':\n"
    "      return toolTextResult(false, 'invalid phone-call arguments')\n"
    "    case 'invalid-clinical-records-connect-link-arguments':\n",
    "    case 'invalid-phone-call-arguments':\n"
    "      return toolTextResult(false, 'invalid phone-call arguments')\n"
    "    case 'invalid-physical-note-arguments':\n"
    "      return toolTextResult(false, 'invalid physical-note arguments')\n"
    "    case 'invalid-clinical-records-connect-link-arguments':\n",
)
send_block = Path("/tmp/new_send_physical_note_block.txt").read_text().rstrip() + "\n"
replace_once(
    path,
    "    case 'create-phone-call': {\n",
    send_block + "    case 'create-phone-call': {\n",
)

# packages/assistant-engine/src/assistant/execution-context.ts
path = "packages/assistant-engine/src/assistant/execution-context.ts"
append_after(
    path,
    "import type {\n  HostedPhoneCallStartRequest,\n  HostedPhoneCallStartResponse,\n} from '@murphai/hosted-execution/phone-calls'\n",
    "import type {\n  HostedPhysicalNoteSendRequest,\n  HostedPhysicalNoteSendResponse,\n} from '@murphai/hosted-execution/physical-notes'\n",
)
replace_once(
    path,
    "export interface AssistantPhoneCallPort {\n"
    "  start(\n"
    "    request: HostedPhoneCallStartRequest,\n"
    "    context?: {\n"
    "      signal?: AbortSignal | null\n"
    "    },\n"
    "  ): Promise<HostedPhoneCallStartResponse>\n"
    "}\n\n"
    "export type AssistantPrivateImageContentType =\n",
    "export interface AssistantPhoneCallPort {\n"
    "  start(\n"
    "    request: HostedPhoneCallStartRequest,\n"
    "    context?: {\n"
    "      signal?: AbortSignal | null\n"
    "    },\n"
    "  ): Promise<HostedPhoneCallStartResponse>\n"
    "}\n\n"
    "export interface AssistantPhysicalNotePort {\n"
    "  send(\n"
    "    request: HostedPhysicalNoteSendRequest,\n"
    "    context?: {\n"
    "      signal?: AbortSignal | null\n"
    "    },\n"
    "  ): Promise<HostedPhysicalNoteSendResponse>\n"
    "}\n\n"
    "export type AssistantPrivateImageContentType =\n",
)
replace_once(
    path,
    "  planUsageTool?: AssistantHostedPlanUsageTool | null\n"
    "  privateImageUrlPublisher?: AssistantHostedPrivateImageUrlPublisher | null\n",
    "  planUsageTool?: AssistantHostedPlanUsageTool | null\n"
    "  physicalNotes?: AssistantPhysicalNotePort | null\n"
    "  privateImageUrlPublisher?: AssistantHostedPrivateImageUrlPublisher | null\n",
)
replace_once(
    path,
    "  const phoneCalls = normalizeAssistantPhoneCallPort(hosted?.phoneCalls)\n"
    "  const privateImageUrlPublisher = normalizeAssistantPrivateImageUrlPublisher(\n",
    "  const phoneCalls = normalizeAssistantPhoneCallPort(hosted?.phoneCalls)\n"
    "  const physicalNotes = normalizeAssistantPhysicalNotePort(hosted?.physicalNotes)\n"
    "  const privateImageUrlPublisher = normalizeAssistantPrivateImageUrlPublisher(\n",
)
replace_once(
    path,
    "      ...(planUsageTool ? { planUsageTool } : {}),\n"
    "      ...(privateImageUrlPublisher ? { privateImageUrlPublisher } : {}),\n",
    "      ...(planUsageTool ? { planUsageTool } : {}),\n"
    "      ...(physicalNotes ? { physicalNotes } : {}),\n"
    "      ...(privateImageUrlPublisher ? { privateImageUrlPublisher } : {}),\n",
)
replace_once(
    path,
    "function normalizeAssistantPhoneCallPort(\n"
    "  input: AssistantHostedExecutionContext['phoneCalls'] | undefined,\n"
    "): AssistantPhoneCallPort | undefined {\n"
    "  if (!input || typeof input.start !== 'function') {\n"
    "    return undefined\n"
    "  }\n\n"
    "  return {\n"
    "    start: input.start.bind(input),\n"
    "  }\n"
    "}\n\n"
    "function normalizeAssistantPrivateImageUrlPublisher(\n",
    "function normalizeAssistantPhoneCallPort(\n"
    "  input: AssistantHostedExecutionContext['phoneCalls'] | undefined,\n"
    "): AssistantPhoneCallPort | undefined {\n"
    "  if (!input || typeof input.start !== 'function') {\n"
    "    return undefined\n"
    "  }\n\n"
    "  return {\n"
    "    start: input.start.bind(input),\n"
    "  }\n"
    "}\n\n"
    "function normalizeAssistantPhysicalNotePort(\n"
    "  input: AssistantHostedExecutionContext['physicalNotes'] | undefined,\n"
    "): AssistantPhysicalNotePort | undefined {\n"
    "  if (!input || typeof input.send !== 'function') {\n"
    "    return undefined\n"
    "  }\n\n"
    "  return {\n"
    "    send: input.send.bind(input),\n"
    "  }\n"
    "}\n\n"
    "function normalizeAssistantPrivateImageUrlPublisher(\n",
)

# packages/assistant-runtime/src/hosted-runtime/platform.ts
path = "packages/assistant-runtime/src/hosted-runtime/platform.ts"
append_after(
    path,
    "import type {\n  HostedPhoneCallStartRequest,\n  HostedPhoneCallStartResponse,\n} from \"@murphai/hosted-execution/phone-calls\";\n",
    "import type {\n  HostedPhysicalNoteSendRequest,\n  HostedPhysicalNoteSendResponse,\n} from \"@murphai/hosted-execution/physical-notes\";\n",
)
replace_once(
    path,
    "export interface HostedRuntimePhoneCallPort {\n"
    "  start(\n"
    "    request: HostedPhoneCallStartRequest,\n"
    "    context?: {\n"
    "      signal?: AbortSignal | null;\n"
    "    },\n"
    "  ): Promise<HostedPhoneCallStartResponse>;\n"
    "}\n\n"
    "export interface HostedRuntimeMailboxPort {\n",
    "export interface HostedRuntimePhoneCallPort {\n"
    "  start(\n"
    "    request: HostedPhoneCallStartRequest,\n"
    "    context?: {\n"
    "      signal?: AbortSignal | null;\n"
    "    },\n"
    "  ): Promise<HostedPhoneCallStartResponse>;\n"
    "}\n\n"
    "export interface HostedRuntimePhysicalNotePort {\n"
    "  send(\n"
    "    request: HostedPhysicalNoteSendRequest,\n"
    "    context?: {\n"
    "      signal?: AbortSignal | null;\n"
    "    },\n"
    "  ): Promise<HostedPhysicalNoteSendResponse>;\n"
    "}\n\n"
    "export interface HostedRuntimeMailboxPort {\n",
)
replace_once(
    path,
    "  planUsageToolPort?: HostedRuntimePlanUsageToolPort | null;\n"
    "  privateImageUrlPublisher?: AssistantHostedPrivateImageUrlPublisher | null;\n",
    "  planUsageToolPort?: HostedRuntimePlanUsageToolPort | null;\n"
    "  physicalNotes?: HostedRuntimePhysicalNotePort | null;\n"
    "  privateImageUrlPublisher?: AssistantHostedPrivateImageUrlPublisher | null;\n",
)

# apps/web/src/lib/hosted-execution/usage-allowance.ts
path = "apps/web/src/lib/hosted-execution/usage-allowance.ts"
append_after(
    path,
    'import { settleHostedUsageCreditForUsageTx } from "./usage-credits";\n',
    'import {\n'
    '  HOSTED_LOB_USAGE_PRICING_SOURCE,\n'
    '  HOSTED_LOB_USAGE_PRICING_VERSION,\n'
    '  matchHostedLobPhysicalNoteUsageRecord,\n'
    '} from "./usage-lob";\n',
)
lob_pricing_branch = '''\n  const lobPhysicalNote = matchHostedLobPhysicalNoteUsageRecord(record);\n  if (lobPhysicalNote !== null) {\n    assertHostedAiUsageLobPhysicalNoteTokenPricingBasis(tokenPricingBasis);\n    return {\n      kind: "priced",\n      priced: {\n        costUsdMicros: counted ? lobPhysicalNote.providerCostUsdMicros : 0n,\n        counted,\n        pricingSnapshot: {\n          credentialSource,\n          providerCost: {\n            providerCostUsdMicros:\n              lobPhysicalNote.providerCostUsdMicros.toString(),\n            providerPricingVersion:\n              lobPhysicalNote.providerPricingVersion,\n          },\n          pricingSource: HOSTED_LOB_USAGE_PRICING_SOURCE,\n          schema: "murph.hosted-ai-usage-allowance-pricing.v1",\n          tokenPricingBasis,\n        },\n        pricingVersion: HOSTED_LOB_USAGE_PRICING_VERSION,\n      },\n    };\n  }\n'''
replace_once(
    path,
    "  const tokenPricingBasis =\n"
    "    normalizeAssistantUsageTokenPricingBasis(record.tokenPricingBasis);\n\n"
    "  const retellMatch = matchHostedAiUsageRetellPhoneCallRecord(record);\n",
    "  const tokenPricingBasis =\n"
    "    normalizeAssistantUsageTokenPricingBasis(record.tokenPricingBasis);\n"
    + lob_pricing_branch
    + "\n  const retellMatch = matchHostedAiUsageRetellPhoneCallRecord(record);\n",
)
replace_once(
    path,
    "function assertHostedAiUsageAllowanceElevenLabsTokenPricingBasis(\n",
    "function assertHostedAiUsageLobPhysicalNoteTokenPricingBasis(\n"
    "  basis: AssistantUsageTokenPricingBasis,\n"
    "): void {\n"
    "  if (basis !== \"standard\") {\n"
    "    throw new TypeError(\n"
    "      \"Lob physical-note hosted usage must use standard token pricing basis.\",\n"
    "    );\n"
    "  }\n"
    "}\n\n"
    "function assertHostedAiUsageAllowanceElevenLabsTokenPricingBasis(\n",
)
replace_once(
    path,
    "  const tokenPricingBasis =\n"
    "    normalizeAssistantUsageTokenPricingBasis(record.tokenPricingBasis);\n\n"
    "  if (matchHostedAiUsageRetellPhoneCallRecord(record) !== null) {\n",
    "  const tokenPricingBasis =\n"
    "    normalizeAssistantUsageTokenPricingBasis(record.tokenPricingBasis);\n\n"
    "  if (matchHostedLobPhysicalNoteUsageRecord(record) !== null) {\n"
    "    assertHostedAiUsageLobPhysicalNoteTokenPricingBasis(tokenPricingBasis);\n"
    "    return tokenPricingBasis;\n"
    "  }\n\n"
    "  if (matchHostedAiUsageRetellPhoneCallRecord(record) !== null) {\n",
)

# apps/web/prisma/schema.prisma
path = "apps/web/prisma/schema.prisma"
replace_once(
    path,
    "enum HostedPhoneCallStatus {\n"
    "  starting\n"
    "  calling\n"
    "  ended\n"
    "  completed\n"
    "  needs_user\n"
    "  failed\n"
    "}\n\n"
    "model HostedMember {\n",
    "enum HostedPhoneCallStatus {\n"
    "  starting\n"
    "  calling\n"
    "  ended\n"
    "  completed\n"
    "  needs_user\n"
    "  failed\n"
    "}\n\n"
    "enum HostedPhysicalNoteStatus {\n"
    "  starting\n"
    "  accepted\n"
    "  failed\n"
    "}\n\n"
    "model HostedMember {\n",
)
replace_once(
    path,
    "  computerHandoffs               HostedComputerHandoff[]\n"
    "  phoneCalls                     HostedPhoneCall[]\n"
    "  productFeedback                HostedProductFeedback[]\n",
    "  computerHandoffs               HostedComputerHandoff[]\n"
    "  phoneCalls                     HostedPhoneCall[]\n"
    "  physicalNotes                  HostedPhysicalNote[]\n"
    "  productFeedback                HostedProductFeedback[]\n",
)
physical_note_model = '''model HostedPhysicalNote {\n  id                       String                   @id\n  memberId                 String                   @map("member_id")\n  requestKey               String                   @map("request_key")\n  requestFingerprint       String                   @map("request_fingerprint")\n  provider                 String                   @default("lob")\n  providerLetterId         String?                  @unique @map("provider_letter_id")\n  status                   HostedPhysicalNoteStatus @default(starting)\n  complimentaryOfferCode   String?                  @map("complimentary_offer_code")\n  providerCostUsdMicros    BigInt                   @map("provider_cost_usd_micros")\n  pricingVersion           String                   @map("pricing_version")\n  acceptedAt               DateTime?                @map("accepted_at")\n  createdAt                DateTime                 @default(now()) @map("created_at")\n  updatedAt                DateTime                 @updatedAt @map("updated_at")\n  member                   HostedMember             @relation(fields: [memberId], references: [id], onDelete: Cascade)\n\n  @@unique([memberId, requestKey])\n  @@unique([memberId, complimentaryOfferCode])\n  @@index([memberId, createdAt])\n  @@index([status, updatedAt])\n  @@map("hosted_physical_note")\n}\n\n'''
replace_once(
    path,
    "  @@map(\"hosted_phone_call\")\n}\n\nmodel HostedMemberIdentity {\n",
    "  @@map(\"hosted_phone_call\")\n}\n\n" + physical_note_model + "model HostedMemberIdentity {\n",
)
