# Whole-body photobiomodulation package draft

This review bundle was assembled from the authoritative repo snapshot at `repo.snapshot(81).zip`.

Included:
- cautious non-onboarding protocol draft
- family page draft
- conservative `research-artifacts.json`
- 86 normalized drafted source pages from the seam output
- 1 bibliography page

Notes:
- The protocol intentionally omits `experimentOnboarding`.
- One PMCID-based source key was normalized to `source_artifact:pmcid-pmc6091542` to satisfy the repo key-pattern check while preserving the original identifier in aliases.
- Registry and web-page sources remain source-page-only unless redistribution rights are clearly verified.
