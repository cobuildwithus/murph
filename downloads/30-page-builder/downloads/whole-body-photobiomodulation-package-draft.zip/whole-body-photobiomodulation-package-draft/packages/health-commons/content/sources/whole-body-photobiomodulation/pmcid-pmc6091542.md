---
schemaVersion: murph.commons.page.v1
entityType: source_artifact
key: source_artifact:pmcid-pmc6091542
slug: sources/whole-body-photobiomodulation/pmcid-pmc6091542
title: 'Photobiomodulation: Lasers vs Light Emitting Diodes?'
summary: Perspective review comparing laser and LED PBM device classes; useful for explaining why whole-body systems are LED-dominant and why wavelength matching alone does not make device classes interchangeable.
status: draft
quality: usable
aliases:
- pmcid-PMC6091542
- pmid-30044464
- 10.1039/C8PP00176F
categories:
- whole-body-photobiomodulation
relations:
- type: related_protocol
  target: protocol_variant:whole-body-photobiomodulation/whole-body-red-and-near-infrared-light-exposure
- type: parent_family
  target: experiment_family:whole-body-photobiomodulation
source:
  kind: review
  title: 'Photobiomodulation: Lasers vs Light Emitting Diodes?'
  authors: Heiskanen V, Hamblin MR
  year: 2018
  journal: Photochemical & Photobiological Sciences
  citation: 'Heiskanen V, Hamblin MR. Photobiomodulation: lasers vs. light emitting diodes? Photochemical & Photobiological Sciences. 2018;17(8):1003-1017. doi:10.1039/C8PP00176F.'
  pmid: '30044464'
  doi: 10.1039/C8PP00176F
  url: https://pmc.ncbi.nlm.nih.gov/articles/PMC6091542/
researchEvidence:
  designKind: narrative_review
  designLabel: Perspective review comparing laser and LED PBM device classes
  populationLabel: Mixed PBM literature across cells, tissues, animals, and humans; device-class comparison rather than a single cohort
  durationLabel: Not applicable; literature perspective
  aggregateRole: synthesis
  cohortKey: heiskanen-2018-laser-vs-led
protocolEvidence:
- protocolKey: protocol_variant:whole-body-photobiomodulation/whole-body-red-and-near-infrared-light-exposure
  groupId: device-class-background
  stance: context_only
  scope: same_mechanism
  result: not_efficacy_evidence
  endpointKeys:
  - biomarker:device-class
  - biomarker:beam-profile
  - biomarker:irradiance-distribution
  - biomarker:coverage-area
  headline: The review argues LEDs are a durable PBM delivery class with practical advantages for large-area treatment, but laser and LED outputs should not be treated as automatically equivalent.
  implication: Useful for explaining why whole-body beds are LED-heavy and why laser-derived PBM evidence should be translated carefully.
  caveat: Perspective review rather than a direct laser-versus-LED whole-body comparative trial.
  displayPriority: 35
evidenceBucket: Dose, device, and implementation reporting
whyItMatters: Whole-body systems are typically LED-based, so device-class interpretation matters when reading a PBM literature that began in laser-heavy traditions.
potentialMurphEndpoints:
- wavelength
- coverage area
- irradiance distribution
- ease of home or self-use
protocolTakeaway: Use as device-class context for LED-heavy whole-body systems; do not treat it as direct whole-body efficacy evidence.
murphTakeaway: This source helps separate “same wavelength” from “same delivered treatment,” which matters when comparing consumer light beds to probe- or laser-based PBM studies.
studyDesign: Perspective review
modality: Laser versus LED photobiomodulation device-class comparison
claimUse: context-only
murphV1Priority: High
pdfRightsStatus: open_access
---

This source is included for **Dose, device, and implementation reporting**.

**Findings:** This perspective review explains that PBM began in laser-based research but now commonly uses non-coherent sources such as LEDs and broad-band lamps. It highlights practical LED advantages for whole-body and home-adjacent use, including fewer laser-specific safety considerations, easier home use, the ability to irradiate large tissue areas at once, wearable-device potential, and lower cost per mW. It also treats coherence and beam characteristics as meaningful device-class differences, so nominal wavelength matches alone should not be assumed to deliver equivalent exposure.

**Why it matters:** Whole-body PBM systems are usually LED-dominant. This source is therefore more useful for device translation and implementation boundaries than for efficacy claims.

**Potential experiment signals:** device class, beam spread, large-area coverage, home-usability constraints.

**Protocol takeaway:** Use as background for LED-versus-laser interpretation and large-area treatment logic; do not promote it into a direct outcome claim.

**Claim use:** `context-only`.
